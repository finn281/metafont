 Write_me is inspired by handwriting letters. I wanted to reproduce some letters forms i learn at school, 
just the way Metafont reminds me mathematics class i had about coordonates. This font highlight this am
biguity between a human and a no-human connections. Also the fact that computer can‘t «hand» writing 
something. I made thoses letters hard to connect well between them, a bit like a doctor‘s unreadable hand
writing. Here you will find a regular, italic regular, extralight and bold version.

