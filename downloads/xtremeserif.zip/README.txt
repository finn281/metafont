**X-treme Serif** is an experimental serif typeface developed using the Metafont programming language—a system for designing type with code and parameters.  
It creates explosive, dynamic curves through adjustable variables like x-height, cap-height, and pen angle.  
This is a **display typeface**, designed for impactful use in titles, headlines, posters, and other contexts where bold visual expression is key.

Metafont is a system developed by Donald Knuth that defines fonts through mathematical descriptions rather than traditional drawing.  
It allows designers to generate letterforms by writing code, enabling flexible, parametric control over shape and structure.



**X-treme Serif Family**
Core x-height:= 5; cap-height:= 8; pen rotated:= 310°;
Lift x-height:= 5; cap-height:= 18; pen rotated:= 310°;	
Overdrive x-height:= 15; cap-height:= 18; pen rotated:= 310°;
Burnout C1 x-height:= 15; cap-height:= 28; pen rotated:= 50°;Burnout C2 x-height:= 15; cap-height:= 28; pen rotated:= 310°;Whiplash C1 x-height:= 15; cap-height:= 38; pen rotated:= 180°;
Whiplash C2 x-height:= 15; cap-height:= 38; pen rotated:= 310°;

                 ,,,,,,,,,,,,,,,,,,,,
                ( Set it on Whiplash!)
  ♪　∧,＿∧       ( Then dance with me )
  　(´･ω･`) ))   |/'''''''''''''''''''
 (( (　つ　ヽ、　♪
 　　〉 とノ　 )))
 　（__ノ^(＿)

----------------------------------
Designed by Park Nayeon, July 2025
Developed as part of the **Metafont** course by Paul Bernhard at HfG Karlsruhe.
Version: 1.0  