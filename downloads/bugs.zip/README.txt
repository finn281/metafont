Bugs invites a more playful approach to things. By embracing the initially awkward controls of  Metafont, a dynamic, frivolous, and somewhat disobedient display typeface came to be. Thick strokes, round shapes and and a mix of upper- and lowercase letters add to its mischievous character. Bugs dares you: go chill a bit. Touch some grass. Be amused by a bug on your computer and be amazed by a bug on your finger.

Bugs currently comes in one weight and consists of a mixed-case Latin letter set. Recommended use: any shenanigans you can dream up.
