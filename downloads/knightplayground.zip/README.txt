Knight Playground is a monospaced typeface which exhibits a clear-cut appearance with slight handwritten features. It serves both as a text and a display typeface with three cuts: 
>> Light, 
>> Regular 
>> Bold. 
Knight Playground has a wide range of use cases, such as from writing code for automatic pizza ordering to writing sophisticated texts from the middle ages about Arthurian legends. 
